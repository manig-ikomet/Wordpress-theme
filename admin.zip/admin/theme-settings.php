<?php
$of_options = 'of_options';
$weblionmedia = 'weblionmedia';
add_action('init', of_options);

add_action('admin_enqueue_scripts', 'add_themeoption_js');

function add_themeoption_js()
{
	if (isset($_GET['page']) && $_GET['page'] == 'siteoptions') {
		wp_enqueue_script('option-admin', get_template_directory_uri() . '/admin/js/tinymce/tinymce.min.js?ver=1.3');
		//Populate the options array
	}
}
if (!function_exists(of_options)) {
	function of_options()
	{

		global $wlm_themename, $wlm_shortname, $wpdb;
		global $weblionmedia;

		global $tt_options;
		$tt_options = get_option($of_options);

		//Access the WordPress Pages via an Array
		$tt_pages = array();
		$tt_pages_obj = get_pages('sort_column=post_parent,menu_order');
		foreach ($tt_pages_obj as $tt_page) {
			$tt_pages[$tt_page->ID] = $tt_page->post_title;
		}
		$tt_pages_tmp = array_unshift($tt_pages, "Select a page:");


		//get page with blog page templates
		$tt_blog_pages = array();
		$tt_blog_pages[] = '';
		$blog_pages_sql = "SELECT post_title FROM $wpdb->postmeta left join $wpdb->posts on $wpdb->postmeta.post_id = $wpdb->posts.ID WHERE meta_value like 'template-blog%'";
		$blog_pages = $wpdb->get_results($blog_pages_sql);
		foreach ($blog_pages as $blog_page) {
			$tt_blog_pages[] = $blog_page->post_title;
		}

		/*$my_title = 'Blog';
			global $wpdb;
			$mypost = $wpdb->get_row( "SELECT * FROM wp_posts WHERE post_title = '" . $my_title . "' " );
			echo $mypost->ID;*/

		//Access the WordPress Categories via an Array
		$tt_categories = array();
		$tt_categories[0] = __('All categories', $weblionmedia);
		$tt_categories_obj = get_categories('hide_empty=0');
		foreach ($tt_categories_obj as $tt_cat) {
			$tt_categories[$tt_cat->cat_ID] = $tt_cat->cat_name;
		}
		$categories_tmp = $tt_categories;

		//get custom post type categories
		$portf_categories = array();
		$portf_categories[0] = __('Select a category:', $weblionmedia);
		$portf_terms = get_terms('portfolio_entries');
		foreach ($portf_terms as $term) {
			@$portf_categories[$term->term_id] = $term->slug;
		}
		$portf_categories_tmp = $portf_categories;




		//Sample Array for demo purposes
		$sample_array = array("1", "2", "3", "4", "5");

		//Sample Advanced Array - The actual value differs from what the user sees
		$sample_advanced_array = array("image" => "The Image", "post" => "The Post");

		//Folder Paths for "type" => "images"
		$sampleurl =  get_template_directory_uri() . '/admin/images/sample-layouts/';

		$theme_slider_effects = array("sliceDownRight", "sliceDownLeft", "sliceUpRight", "sliceUpLeft", "sliceUpDown", "sliceUpDownLeft", "fold", "fade", "boxRandom", "boxRain", "boxRainReverse", "boxRainGrow", "boxRainGrowReverse");

		$theme_font_size_length = array("", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50");

		/*-----------------------------------------------------------------------------------*/
		/* Create The Custom Site Options Panel
/*-----------------------------------------------------------------------------------*/
		$options = array(); // do not delete this line - sky will fall




		/*
		#############################
		####General Theme Options#### 
		#############################
		*/

		$options[] = array(
			"name" => __('General', $weblionmedia),
			"type" => "heading"
		);

		$options[] = array(
			"name" => __('General Site Options', $weblionmedia),
			"desc" => "",
			"std" => __("Set the general site options.", $weblionmedia),
			"type" => "info"
		);

		$options[] = array(
			"name" => __('Favicon', $weblionmedia),
			"desc" => __('Upload a 16px x 16px image that will represent your website\'s favicon.<br /><br /><em>To ensure cross-browser compatibility, we recommend converting the favicon into .ico format before uploading. (<a href="http://www.favicon.cc/">www.favicon.cc</a>)</em>', $weblionmedia),
			"id" => $wlm_shortname . "_favicon",
			"std" => "",
			"type" => "custom-upload"
		);

		$options[] = array(
			"name" => __('Logo', $weblionmedia),
			"desc" => __('Upload a logo for your site.', $weblionmedia),
			"id" => $wlm_shortname . "_logo",
			"std" => "",
			"type" => "custom-upload"
		);

		$options[] = array(
			"name" => __('Logo Link', $weblionmedia),
			"desc" => __('Logo descriptor for your site.', $weblionmedia),
			"id" => $wlm_shortname . "_logo_Link",
			"std" => "",
			"type" => "text"
		);

		// $options[] = array(
		// 	"name" => __('Logo Descriptor', $weblionmedia),
		// 	"desc" => __('Logo descriptor for your site.', $weblionmedia),
		// 	"id" => $wlm_shortname . "_logo_descriptor",
		// 	"std" => "",
		// 	"type" => "text"
		// );
		// $options[] = array(
		// 	"name" => __('Default Banner Image', $weblionmedia),
		// 	"desc" => __('Set default image for general template', $weblionmedia),
		// 	"id" => $wlm_shortname . "_defalt_image",
		// 	"std" => "",
		// 	"type" => "custom-upload"
		// );
		/*
		#############################
		####Header Theme Options#### 
		#############################
		*/


		$options[] = array(
			"name" => __('Header', $weblionmedia),
			"type" => "heading"
		);




		$options[] = array(
			"name" => __('Enable Sticky Menu', $weblionmedia),
			"desc" => __("To enable sticky navigation", $weblionmedia),
			"id" => $wlm_shortname . "_sticky",
			"std" => "",
			"type" => "checkbox"
		);


		$options[] = array(
			"name" => __('CTA Phone number 1', $weblionmedia),
			"desc" => __("", $weblionmedia),
			"id" => $wlm_shortname . "_phone_number_1",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('CTA Phone number 2', $weblionmedia),
			"desc" => __("", $weblionmedia),
			"id" => $wlm_shortname . "_phone_number_2",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Default Banner Image', $weblionmedia),
			"desc" => __('Set default banner image,If the banner image is not exists in the page.', $weblionmedia),
			"id" => $wlm_shortname . "_defaultbanner",
			"std" => "",
			"type" => "custom-upload"
		);
		/*
		#############################
		####Banner Content#### 
		#############################
		*/


		$options[] = array(
			"name" => __('Home Banner', $weblionmedia),
			"type" => "heading"
		);




		$options[] = array(
			"name" => __('Doctor CTA text', $weblionmedia),
			"desc" => __("", $weblionmedia),
			"id" => $wlm_shortname . "_f_a_text",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Doctor CTA Link', $weblionmedia),
			"desc" => __("", $weblionmedia),
			"id" => $wlm_shortname . "_f_a_link",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Doctor CTA Target', $weblionmedia),
			"desc" => __("To enable open in new window", $weblionmedia),
			"id" => $wlm_shortname . "_f_a_target",
			"std" => "",
			"type" => "checkbox"
		);
		$options[] = array(
			"name" => __('Service CTA text', $weblionmedia),
			"desc" => __("", $weblionmedia),
			"id" => $wlm_shortname . "_service_a_text",
			"std" => "",
			"type" => "text"
		);
		// $options[] = array( "name" => __('Service CTA Link',$weblionmedia),
		// 			"desc" => __("",$weblionmedia),
		// 			"id" => $wlm_shortname."_service_a_link",
		// 			"std" => "",
		// 			"type" => "text");
		$options[] = array(
			"name" => __('Patients CTA text', $weblionmedia),
			"desc" => __("", $weblionmedia),
			"id" => $wlm_shortname . "_patients_a_text",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Patients CTA Link', $weblionmedia),
			"desc" => __("", $weblionmedia),
			"id" => $wlm_shortname . "_patients_a_link",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Patients CTA Target', $weblionmedia),
			"desc" => __("To enable open in new window", $weblionmedia),
			"id" => $wlm_shortname . "_patients_a_target",
			"std" => "",
			"type" => "checkbox"
		);
		$options[] = array(
			"name" => __('Desktop Height', $weblionmedia),
			"desc" => __("Add custom desktop slider height in px", $weblionmedia),
			"id" => $wlm_shortname . "_desktopheight",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Portrait Height', $weblionmedia),
			"desc" => __("Add custom portrait slider height in px", $weblionmedia),
			"id" => $wlm_shortname . "_portraitheight",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Landscape Height', $weblionmedia),
			"desc" => __("Add custom landscape slider height in px", $weblionmedia),
			"id" => $wlm_shortname . "_landscapeheight",
			"std" => "",
			"type" => "text"
		);
		
	/*
		#############################
		####Sidebar#### 
		#############################
		*/
		$options[] = array(
			"name" => __('Sidebar', $weblionmedia),
			"type" => "heading"
		);
		
		$options[] = array(
			"name" => __('Enable Sidebar in our team', $weblionmedia),
			"desc" => __("To enable the sidebar in our team template", $weblionmedia),
			"id" => $wlm_shortname . "_sidebar_team",
			"std" => "",
			"type" => "checkbox"
		);

		/*
		#############################
		####Style#### 
		#############################
		*/
		$options[] = array(
			"name" => __('Style', $weblionmedia),
			"type" => "heading"
		);
		$options[] = array(
			"name" => __('Banner Title Background Color', $weblionmedia),
			"desc" => __('Change banner title background color.', $weblionmedia),
			"id" => $wlm_shortname . "_banner_title_color",
			"std" => "",
			"type" => "color"
		);
		$options[] = array(
			"name" => __('Enable Preloader', $weblionmedia),
			"desc" => __("To enable preloader design", $weblionmedia),
			"id" => $wlm_shortname . "_preloder",
			"std" => "",
			"type" => "checkbox"
		);

		/*
		#############################
		#### Advanced #### 
		#############################
		*/
		$options[] = array(
			"name" => __('Advanced', $weblionmedia),
			"type" => "heading"
		);
		$options[] = array(
			"name" => __('Tracking Code', $weblionmedia),
			"desc" => __('Paste your tracking code here. This will be added into the header template of your theme. Place code inside script tags.', $weblionmedia),
			"id" => $wlm_shortname . "_trackingcodeheader",
			"std" => "",
			"type" => "textarea"
		);
		$options[] = array(
			"name" => __('Space before body tag', $weblionmedia),
			"desc" => __("Only accepts javascript code, wrapped with script tags and valid HTML markup inside the body tag.", $weblionmedia),
			"id" => $wlm_shortname . "_trackingcodebody",
			"std" => "",
			"type" => "textarea"
		);
		$options[] = array(
			"name" => __('Footer Scripts', $weblionmedia),
			"desc" => __("Paste your script code here. This will be added into the footer template of your theme. Place code inside script tags.", $weblionmedia),
			"id" => $wlm_shortname . "_footerscript",
			"std" => "",
			"type" => "textarea"
		);
		/*
		#############################
		####Footer Theme Options#### 
		#############################
		*/

		$options[] = array(
			"name" => __('Footer', $weblionmedia),
			"type" => "heading"
		);
		$options[] = array(
			"name" => __('Footer Logo', $weblionmedia),
			"desc" => __('Upload a Footer logo for your site.', $weblionmedia),
			"id" => $wlm_shortname . "_footer_logo",
			"std" => "",
			"type" => "custom-upload"
		);

		$options[] = array(
			"name" => __('Phone Number', $weblionmedia),
			"desc" => __("Add your phone number in footer", $weblionmedia),
			"id" => $wlm_shortname . "_footer_phone_number",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Address', $weblionmedia),
			"desc" => __("Add your address in footer", $weblionmedia),
			"id" => $wlm_shortname . "_footer_address",
			"std" => "",
			"type" => "textarea"
		);
		$options[] = array(
			"name" => __('Google Map Link', $weblionmedia),
			"desc" => __("Add your address Google Map Direction link for footer", $weblionmedia),
			"id" => $wlm_shortname . "_footer_address_googlemap",
			"std" => "",
			"type" => "text"
		);

		$options[] = array(
			"name" => __('Second Column Title', 'weblionmedia'),
			"desc" => __("You can add title to footer menu second menu", "weblionmedia"),
			"id" => $wlm_shortname . "_footer_title_two",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Third Column Title', 'weblionmedia'),
			"desc" => __("You can add title to footer third menu", "weblionmedia"),
			"id" => $wlm_shortname . "_footer_title_three",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Fourth Column Title', 'weblionmedia'),
			"desc" => __("You can add title to footer fourth menu", "weblionmedia"),
			"id" => $wlm_shortname . "_footer_title_fourth",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Visit Link Title', 'weblionmedia'),
			"desc" => __("You can add Visit Link to  fourth Column", "weblionmedia"),
			"id" => $wlm_shortname . "_footer_visit_link_title",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Visit Link', 'weblionmedia'),
			"desc" => __("You can add Visit Link to footer fourth Column", "weblionmedia"),
			"id" => $wlm_shortname . "_footer_visit_link",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Visit Link Target', $weblionmedia),
			"desc" => __("To enable New Window", $weblionmedia),
			"id" => $wlm_shortname . "_footer_visit_target",
			"std" => "",
			"type" => "checkbox"
		);
		/*
		#############################
		####Social Media Feed Options#### 
		#############################
		*/
		$options[] = array(
			"name" => __('Social Media Feed', $weblionmedia),
			"type" => "heading"
		);
		$options[] = array(
			"name" => __('Social Feed Title', 'weblionmedia'),
			"desc" => __("Social media feed Title", "weblionmedia"),
			"id" => $wlm_shortname . "_socialmediatitle",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Social Feed Icon', 'weblionmedia'),
			"desc" => __("Social feed icon", "weblionmedia"),
			"id" => $wlm_shortname . "_socialmedialogo",
			"std" => "",
			"type" => "custom-upload"
		);
		$options[] = array(
			"name" => __('Youtube Channel ID', 'weblionmedia'),
			"desc" => __("Add Youtube Channel ID", "weblionmedia"),
			"id" => $wlm_shortname . "_youtubefeed",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Instagram Page ID', 'weblionmedia'),
			"desc" => __("Add Instagram Page ID", "weblionmedia"),
			"id" => $wlm_shortname . "_instagram_id",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Instagram Access Token', 'weblionmedia'),
			"desc" => __("Add Instagram Access Token", "weblionmedia"),
			"id" => $wlm_shortname . "_instagram_access_token",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Instagram Client ID', 'weblionmedia'),
			"desc" => __("Add Instagram Client ID", "weblionmedia"),
			"id" => $wlm_shortname . "_instagram_client_id",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Facebook App ID', 'weblionmedia'),
			"desc" => __("Add Facebook App ID", "weblionmedia"),
			"id" => $wlm_shortname . "_facebook_app_id",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Facebook App Secret', 'weblionmedia'),
			"desc" => __("Add Facebook App Secret", "weblionmedia"),
			"id" => $wlm_shortname . "_facebook_app_secret",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Facebook Page ID', 'weblionmedia'),
			"desc" => __("Add Facebook Page ID", "weblionmedia"),
			"id" => $wlm_shortname . "_facebook_page_id",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Twitter Consumer Key', 'weblionmedia'),
			"desc" => __("Add Twitter Consumer Key", "weblionmedia"),
			"id" => $wlm_shortname . "_twitter_consumer_key",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Twitter Consumer Secret', 'weblionmedia'),
			"desc" => __("Add Twitter Consumer Secret", "weblionmedia"),
			"id" => $wlm_shortname . "_twitter_consumer_secret",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Twitter Page ID', 'weblionmedia'),
			"desc" => __("Add Twitter Page ID", "weblionmedia"),
			"id" => $wlm_shortname . "_twitter_page_id",
			"std" => "",
			"type" => "text"
		);
		$options[] = array(
			"name" => __('Post Count ', 'weblionmedia'),
			"desc" => __("Social Count on each Social Feed", "weblionmedia"),
			"id" => $wlm_shortname . "_postcount",
			"std" => "",
			"type" => "text"
		);
		/*
		#############################
		####Social Media Theme Options#### 
		#############################
		*/
		$options[] = array(
			"name" => __('Social Media', $weblionmedia),
			"type" => "heading"
		);
		// $options[] = array( "name" => __('LinkedIn Icon',$weblionmedia),
		// 			"desc" => __('Upload a LinkedIn icon for your site.',$weblionmedia),
		// 			"id" => $wlm_shortname."_linkedIn_icon",
		// 			"std" => "",
		// 			"type" => "custom-upload");	

		$options[] = array(
			"name" => __('LinkedIn Link', $weblionmedia),
			"desc" => __("Add your LinkedIn Link in footer", $weblionmedia),
			"id" => $wlm_shortname . "_linkedIn_link",
			"std" => "",
			"type" => "text"
		);
		// $options[] = array( "name" => __('Facebook Icon',$weblionmedia),
		// 			"desc" => __('Upload a Facebook icon for your site.',$weblionmedia),
		// 			"id" => $wlm_shortname."_facebook_icon",
		// 			"std" => "",
		// 			"type" => "custom-upload");	

		$options[] = array(
			"name" => __('Facebook Link', $weblionmedia),
			"desc" => __("Add your Facebook Link in footer", $weblionmedia),
			"id" => $wlm_shortname . "_facebook_link",
			"std" => "",
			"type" => "text"
		);

		// $options[] = array( "name" => __('Youtube Icon',$weblionmedia),
		// "desc" => __('Upload a Youtube icon for your site.',$weblionmedia),
		// "id" => $wlm_shortname."_youtube_icon",
		// "std" => "",
		// "type" => "custom-upload");	

		$options[] = array(
			"name" => __('Youtube Link', $weblionmedia),
			"desc" => __("Add your Youtube Link in footer", $weblionmedia),
			"id" => $wlm_shortname . "_youtube_link",
			"std" => "",
			"type" => "text"
		);
		// $options[] = array( "name" => __('Twitter Icon',$weblionmedia),
		// 			"desc" => __('Upload a Twitter icon for your site.',$weblionmedia),
		// 			"id" => $wlm_shortname."_twitter_icon",
		// 			"std" => "",
		// 			"type" => "custom-upload");	

		$options[] = array(
			"name" => __('Twitter Link', $weblionmedia),
			"desc" => __("Add your Twitter Link in footer", $weblionmedia),
			"id" => $wlm_shortname . "_twitter_link",
			"std" => "",
			"type" => "text"
		);
		// 			$options[] = array( "name" => __('Instagram Icon',$weblionmedia),
		// 			"desc" => __('Upload a Instagram icon for your site.',$weblionmedia),
		// 			"id" => $wlm_shortname."_instagram_icon",
		// 			"std" => "",
		// 			"type" => "custom-upload");	

		$options[] = array(
			"name" => __('Instagram Link', $weblionmedia),
			"desc" => __("Add your Instagram Link in footer", $weblionmedia),
			"id" => $wlm_shortname . "_instagram_link",
			"std" => "",
			"type" => "text"
		);

		$options[] = array(
			"name" => __('Google API', $weblionmedia),
			"type" => "heading"
		);
		$options[] = array(
			"name" => __('Google map API', $weblionmedia),
			"desc" => __("Add to configure the google map api for Maps", $weblionmedia),
			"id" => $wlm_shortname . "_google_map_api",
			"std" => "",
			"type" => "text"
		);

		$options[] = array(
			"name" => __('Copy Rights', $weblionmedia),
			"type" => "heading"
		);
		$options[] = array(
			"name" => __('Left side Content', $weblionmedia),
			"desc" => __("Add your copy rights left side in footer", $weblionmedia),
			"id" => $wlm_shortname . "_footer_copyright_left",
			"std" => "",
			"type" => "textarea"
		);

		$options[] = array(
			"name" => __('Right side Content', $weblionmedia),
			"desc" => __("Add your copy rights right side in footer", $weblionmedia),
			"id" => $wlm_shortname . "_footer_copyright_right",
			"std" => "",
			"type" => "textarea"
		);
		update_option('of_template', $options);
		update_option('of_themename', $wlm_themename);
		update_option('of_shortname', $wlm_shortname);
	}
}
