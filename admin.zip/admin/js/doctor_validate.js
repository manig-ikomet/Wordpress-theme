 jQuery(document).ready(function() {

	jQuery('#post').submit(function() {
	var clikedForm = jQuery(this); // Select Form
		 
		jQuery("#age_specialist").parent().find('span').remove();
		jQuery('#age_specialist').css({ "border": "1px solid #ddd"});
		jQuery("#specialist").parent().find('span').remove();
		jQuery('#specialist').css({ "border": "1px solid #ddd"});
		jQuery("#affiliation").parent().find('span').remove();
		jQuery('#affiliation').css({ "border": "1px solid #ddd"});
		jQuery("#address_location").parent().find('span').remove();
		jQuery('#address_location').css({ "border": "1px solid #ddd"});
		jQuery("#address_latitude").parent().find('span').remove();
		jQuery('#address_latitude').css({ "border": "1px solid #ddd"});
		jQuery("#address_longitude").parent().find('span').remove();
		jQuery('#address_longitude').css({ "border": "1px solid #ddd"});


		jQuery("#address_country").parent().find('span').remove();
		jQuery('#address_country').css({ "border": "1px solid #ddd"});
		jQuery("#address_state").parent().find('span').remove();
		jQuery('#address_state').css({ "border": "1px solid #ddd"});
		jQuery("#address_city").parent().find('span').remove();
		jQuery('#address_city').css({ "border": "1px solid #ddd"});
		jQuery("#address_zipcode").parent().find('span').remove();
		jQuery('#address_zipcode').css({ "border": "1px solid #ddd"});
		jQuery("#address_street").parent().find('span').remove();
		jQuery('#address_street').css({ "border": "1px solid #ddd"});
		
		var invalid=0; 	
		if (clikedForm.find('#age_specialist').length >0  && jQuery('#age_specialist').val()=='')
		{
			jQuery('#age_specialist').css({ "border": "1px solid red"});
 			jQuery("#age_specialist").after('<span class="error" style="color:red">Age Specialist is required.</span>');
			jQuery('#age_specialist').focus();	
			invalid++;
			
		}	
		
		if (clikedForm.find('#specialist').length >0  && jQuery('#specialist').val()=='')
		{
			jQuery('#specialist').css({ "border": "1px solid red"});
 			jQuery("#specialist").after('<span class="error" style="color:red">Specialist is required.</span>');
			jQuery('#specialist').focus();	
			invalid++;
			
		}	
		
		if (clikedForm.find('#affiliation').length >0 && clikedForm.find('#affiliation').val() =='')
		{
			jQuery('#affiliation').css({ "border": "1px solid red"});
 			jQuery("#affiliation").after('<span class="error" style="color:red">Affiliation is required.</span>');
			jQuery('#affiliation').focus();	
			invalid++;
			
		}	
		
		if (clikedForm.find('#address_location').length >0 && clikedForm.find('#address_location').val() =='')
		{
			jQuery('#address_location').css({ "border": "1px solid red"});
 			jQuery("#address_location").after('<span class="error" style="color:red">Address is required.</span>');
			jQuery('#address_location').focus();	
			invalid++;
			
		}	
		if (clikedForm.find('#address_latitude').length >0 && clikedForm.find('#address_latitude').val() =='')
		{
			jQuery('#address_latitude').css({ "border": "1px solid red"});
 			jQuery("#address_latitude").after('<span class="error" style="color:red">Latitude is required.</span>');
			jQuery('#address_latitude').focus();	
			invalid++;
			
		}	
		if (clikedForm.find('#address_longitude').length >0 && clikedForm.find('#address_longitude').val() =='')
		{
			jQuery('#address_longitude').css({ "border": "1px solid red"});
 			jQuery("#address_longitude").after('<span class="error" style="color:red">Longitude is required.</span>');
			jQuery('#address_longitude').focus();	
			invalid++;
			
		}	
			if (clikedForm.find('#address_country').length >0  && jQuery('#address_country').val()=='')
		{
			jQuery('#address_country').css({ "border": "1px solid red"});
 			jQuery("#address_country").after('<span class="error" style="color:red"> Country is required.</span>');
			jQuery('#address_country').focus();	
			invalid++;
			
		}	
		
		if (clikedForm.find('#address_state').length >0  && jQuery('#address_state').val()=='')
		{
			jQuery('#address_state').css({ "border": "1px solid red"});
 			jQuery("#address_state").after('<span class="error" style="color:red"> State is required.</span>');
			jQuery('#address_state').focus();	
			invalid++;
			
		}	
		
		if (clikedForm.find('#address_city').length >0 && clikedForm.find('#address_city').val() =='')
		{
			jQuery('#address_city').css({ "border": "1px solid red"});
 			jQuery("#address_city").after('<span class="error" style="color:red"> City is required.</span>');
			jQuery('#address_city').focus();	
			invalid++;
			
		}	
		
		if (clikedForm.find('#address_zipcode').length >0 && clikedForm.find('#address_zipcode').val() =='')
		{
			jQuery('#address_zipcode').css({ "border": "1px solid red"});
 			jQuery("#address_zipcode").after('<span class="error" style="color:red"> Zipcode is required.</span>');
			jQuery('#address_zipcode').focus();	
			invalid++;
			
		}	
		
		if (clikedForm.find('#address_street').length >0 && clikedForm.find('#address_street').val() =='')
		{
			jQuery('#address_street').css({ "border": "1px solid red"});
 			jQuery("#address_street").after('<span class="error" style="color:red"> Street is required.</span>');
			jQuery('#address_street').focus();	
			invalid++;
			
		}	
		if(invalid==0)
		{
			return  true;
		}
		else
		{
			return  false;
		}
		
		
			
		
	
	});
jQuery("#phone_number").mask("999-999-9999");	   
});
