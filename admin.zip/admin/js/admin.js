/*global simpleresponsiveslider_admin_params */
/**
 * Theme Options and Metaboxes.
 */

var $=jQuery;
/*
jQuery(document).ready(function($) {
    /**
     * Image plupload adds.
     */
    /*
  
    $('#page_template').change(function() {

      //console.log($(this).val());

       if($(this).val() == 'about-us.php'){

						$('#contact_lat').show();
						$('#contact_long').show();
						$('#contact_address').show();
						$('#contact_shortcode').show();
						$('#postdivrich').hide();
						$('#banner_image_check').hide();
		
       }
       else if($(this).val() == 'page-with-image.php'){

							$('#banner_image_check').hide();
							$('#contact_lat').hide();
							$('#contact_long').hide();
							$('#contact_address').hide();
							$('#contact_shortcode').hide();

       }
       else{

						$('#contact_lat').hide();
						$('#contact_long').hide();
						$('#contact_address').hide();
						$('#contact_shortcode').hide();
						$('#postdivrich').show();
						$('#banner_image_check').show();
		
		
       }

    });


   if($('#page_template').val() == 'contact.php') {

	
	  $('#contact_lat').css('display','block');
		$('#contact_long').show();
		$('#contact_address').show();
		$('#contact_shortcode').show();
		$('#postdivrich').hide();
		$('#banner_image_check').hide();
		
   }

   if($('#page_template').val() == 'page-with-image.php'){
	
				$('#banner_image_check').hide();
   }
   
    
});
*/
jQuery(function($){
    /*
     * Select/Upload image(s) event
     */
    $('body').on('click', '.misha_upload_image_button', function(e){
		//alert();
        e.preventDefault();

            var button = $(this),
                custom_uploader = wp.media({
            title: 'Insert image',
            library : {
                // uncomment the next line if you want to attach image to the current post
                // uploadedTo : wp.media.view.settings.post.id, 
                type : 'image'
            },
            button: {
                text: 'Use this image' // button label text
            },
            multiple: false // for multiple image selection set to true
        }).on('select', function() { // it also has "open" and "close" events 
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            $(button).removeClass('button').html('<img class="true_pre_image" src="' + attachment.url + '" style="max-width:95%;display:block;" />').next().val(attachment.id).next().show();
            /* if you sen multiple to true, here is some code for getting the image IDs
            var attachments = frame.state().get('selection'),
                attachment_ids = new Array(),
                i = 0;
            attachments.each(function(attachment) {
                attachment_ids[i] = attachment['id'];
                console.log( attachment );
                i++;
            });
            */
        })
        .open();
    });

    /*
     * Remove image event
     */
    $('body').on('click', '.misha_remove_image_button', function(){
        $(this).hide().prev().val('').prev().addClass('button').html('Upload image');
        return false;
    });

});



