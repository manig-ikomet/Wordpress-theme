  jQuery(document).ready(function() {

	jQuery('#post').submit(function() {
	var clikedForm = jQuery(this); // Select Form
		 
		jQuery("#address_health_country").parent().find('span').remove();
		jQuery('#address_health_country').css({ "border": "1px solid #ddd"});
		jQuery("#address_health_state").parent().find('span').remove();
		jQuery('#address_health_state').css({ "border": "1px solid #ddd"});
		jQuery("#address_health_city").parent().find('span').remove();
		jQuery('#address_health_city').css({ "border": "1px solid #ddd"});
		jQuery("#address_health_zipcode").parent().find('span').remove();
		jQuery('#address_health_zipcode').css({ "border": "1px solid #ddd"});
		jQuery("#address_health_street").parent().find('span').remove();
		jQuery('#address_health_street').css({ "border": "1px solid #ddd"});
		jQuery("#address_health_latitude").parent().find('span').remove();
		jQuery('#address_health_latitude').css({ "border": "1px solid #ddd"});
		jQuery("#address_health_longitude").parent().find('span').remove();
		jQuery('#address_health_longitude').css({ "border": "1px solid #ddd"});
		jQuery("#health_care_type").parent().find('span').remove();
		jQuery('#health_care_type').css({ "border": "1px solid #ddd"});
		jQuery("#address_health_district").parent().find('span').remove();
		jQuery('#address_health_district').css({ "border": "1px solid #ddd"});
		
		var invalid=0; 	
		if (clikedForm.find('#address_health_country').length >0  && jQuery('#address_health_country').val()=='')
		{
			jQuery('#address_health_country').css({ "border": "1px solid red"});
 			jQuery("#address_health_country").after('<span class="error" style="color:red"> Country is required.</span>');
			jQuery('#address_health_country').focus();	
			invalid++;
			
		}	
		
		if (clikedForm.find('#address_health_state').length >0  && jQuery('#address_health_state').val()=='')
		{
			jQuery('#address_health_state').css({ "border": "1px solid red"});
 			jQuery("#address_health_state").after('<span class="error" style="color:red"> State is required.</span>');
			jQuery('#address_health_state').focus();	
			invalid++;
			
		}	
		
		if (clikedForm.find('#address_health_city').length >0 && clikedForm.find('#address_health_city').val() =='')
		{
			jQuery('#address_health_city').css({ "border": "1px solid red"});
 			jQuery("#address_health_city").after('<span class="error" style="color:red"> City is required.</span>');
			jQuery('#address_health_city').focus();	
			invalid++;
			
		}	
		
		if (clikedForm.find('#address_health_zipcode').length >0 && clikedForm.find('#address_health_zipcode').val() =='')
		{
			jQuery('#address_health_zipcode').css({ "border": "1px solid red"});
 			jQuery("#address_health_zipcode").after('<span class="error" style="color:red"> Zipcode is required.</span>');
			jQuery('#address_health_zipcode').focus();	
			invalid++;
			
		}	
		
		if (clikedForm.find('#address_health_street').length >0 && clikedForm.find('#address_health_street').val() =='')
		{
			jQuery('#address_health_street').css({ "border": "1px solid red"});
 			jQuery("#address_health_street").after('<span class="error" style="color:red"> Street is required.</span>');
			jQuery('#address_health_street').focus();	
			invalid++;
			
		}	
		if (clikedForm.find('#address_health_latitude').length >0 && clikedForm.find('#address_health_latitude').val() =='')
		{
			jQuery('#address_health_latitude').css({ "border": "1px solid red"});
 			jQuery("#address_health_latitude").after('<span class="error" style="color:red">Latitude is required.</span>');
			jQuery('#address_health_latitude').focus();	
			invalid++;
			
		}	
		if (clikedForm.find('#address_health_longitude').length >0 && clikedForm.find('#address_health_longitude').val() =='')
		{
			jQuery('#address_health_longitude').css({ "border": "1px solid red"});
 			jQuery("#address_health_longitude").after('<span class="error" style="color:red">Longitude is required.</span>');
			jQuery('#address_health_longitude').focus();	
			invalid++;
			
		}	
		if (clikedForm.find('#health_care_type').length >0 && clikedForm.find('#health_care_type').val() =='')
		{
			jQuery('#health_care_type').css({ "border": "1px solid red"});
 			jQuery("#health_care_type").after('<span class="error" style="color:red">Healthcare type is required.</span>');
			jQuery('#health_care_type').focus();	
			invalid++;
			
		}
		if (clikedForm.find('#address_health_district').length >0 && clikedForm.find('#address_health_district').val() =='')
		{
			jQuery('#address_health_district').css({ "border": "1px solid red"});
 			jQuery("#address_health_district").after('<span class="error" style="color:red">County is required.</span>');
			jQuery('#address_health_district').focus();	
			invalid++;
			
		}	
		
		if(invalid==0)
		{
			return  true;
		}
		else
		{
			return  false;
		}
		
			
			
		
	
	});
	jQuery('#health_phone_number').mask("(999) 999-9999",{placeholder:""});
	
});
