 jQuery(document).ready(function() {
	jQuery('#post').submit(function() {

		jQuery("#title").parent().find('span').remove();
		jQuery('#title').css({ "border": "1px solid #ddd"});
		jQuery("#edu_qua").parent().find('span').remove();
		//jQuery('#edu_qua').css({ "border": "1px solid #ddd"});
		jQuery('.post_social').each(function()
		{
			jQuery(this).css({ "border": "1px solid #ddd"});
	 		jQuery(this).parent().find('span').remove();	
		});

			

		if(jQuery('#title').val() =='')
		{
		
                jQuery('#title').css({ "border": "1px solid red"});
 		jQuery("#title").after('<span class="error" style="color:red">Title is required.</span>');
		jQuery('#title').focus();
		return false;	
		}
		/*if(jQuery('#edu_qua').val() =='')
		{
			jQuery('#edu_qua').css({ "border": "1px solid red"});
 			jQuery("#edu_qua").after('<span class="error" style="color:red">Education qualification is required.</span>');
			jQuery('#edu_qua').focus();	
			return false;
			
		}	*/	
		var invalid=0; 																																																																																																																																																																																																											
		jQuery('.post_social').each(function()
		{
			var txt = jQuery(this).val();
			if(txt!='')
			{
				var re = /(http(s)?:\\)?([\w-]+\.)+[\w-]+[.com|.in|.org]+(\[\?%&=]*)?/;

				if (!re.test(txt)) 
				{
					jQuery(this).css({ "border": "1px solid red"});
	 				jQuery(this).after('<span class="error" style="color:red">Enter valid url only.</span>');	
					jQuery(this).focus();	
					invalid++;

				}
				
			}
			
		});
		
		if(invalid==0)
		{
		return true;
		}
		else
		{
		return false;
		}
	
	});
});
