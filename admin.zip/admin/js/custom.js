 $(window).on("scroll", function() {
				if ($(this).scrollTop() > 100) {
				   $("header").css("background","#ffffff");
				}
				else {
				   $("header").css("background","transparent");
				}
			 });
			 
$('.translation-links a').click(function() {
		  var lang = $(this).data('lang');
		  var $frame = $('.goog-te-menu-frame:first');
		  if (!$frame.size()) {
			alert("Error: Could not find Google translate frame.");
			return false;
		  }
		  $frame.contents().find('.goog-te-menu2-item span.text:contains('+lang+')').get(0).click();
		  return false;
		}); 
		
		function trans()
		{
		  var lang = 'English';
		  var $frame = $('.goog-te-menu-frame:first');
		  if (!$frame.size()) {
			alert("Error: Could not find Google translate frame.");
			return false;
		  }
		  $frame.contents().find('.goog-te-menu2-item span.text:contains('+lang+')').get(0).click();
		   $('.home_header').css('top','40px');
		   var iframe = $('.goog-te-banner-frame').contents();

		iframe.find('.goog-close-link').click(function(event){
		   $('.home_header').css('top','0px');
		});
		  return false;
		}
		
		
		
		var refreshId =setInterval(function(){ 
			var $frame = $('.goog-te-banner-frame');
		  if ($frame.size()) {
			 $('.home_header').css('top','40px');
			   var iframe = $('.goog-te-banner-frame').contents();

		iframe.find('.goog-close-link').click(function(event){
		   $('.home_header').css('top','0px');
		});
			 clearInterval(refreshId);
		  }	 
			} , 300);
			
			setInterval(function(){ 
			$('#goog-gt-tt').hide();
			} , 3000);
			
			
			(function() {
				// trim polyfill : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/Trim
				if (!String.prototype.trim) {
					(function() {
						// Make sure we trim BOM and NBSP
						var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
						String.prototype.trim = function() {
							return this.replace(rtrim, '');
						};
					})();
				}

				[].slice.call( document.querySelectorAll( 'input.input__field' ) ).forEach( function( inputEl ) {
					// in case the input is already filled..
					if( inputEl.value.trim() !== '' ) {
						classie.add( inputEl.parentNode, 'input--filled' );
					}

					// events:
					inputEl.addEventListener( 'focus', onInputFocus );
					inputEl.addEventListener( 'blur', onInputBlur );
				} );

				function onInputFocus( ev ) {
					classie.add( ev.target.parentNode, 'input--filled' );
				}

				function onInputBlur( ev ) {
					/*if( ev.target.value.trim() === '' ) {
						classie.remove( ev.target.parentNode, 'input--filled' );
					}*/classie.remove( ev.target.parentNode, 'input--filled' );
				}
			})();
		
        hiddenNavBar = {
            $menu: $('#menu'),
            init: function () {
                this.resize();
                $('<div id="on-hidden-menu"><div class="toggle "><span></span></div><ul></ul></div>').hide().insertAfter(this.$menu);
                // toggle
                $('#on-hidden-menu .toggle').click(function () {
                    $('#on-hidden-menu').toggleClass('open');
                });

                // win load & resize
                $(window).on('load resize', function () {
                    hiddenNavBar.resize();
                });
            },
            resize: function () {
                setTimeout(function () {
                    var menuWidth = $('ul', this.$menu).width() + 60;
                    var winW = $(window).width();

                    console.log(menuWidth, winW);

                    if (menuWidth > winW) {
                        console.log('init');

                        $('#on-hidden-menu').show();
                        $clone = $('li:not(".on-hidden"):last', this.$menu).addClass('on-hidden').clone();

                        if ($clone.parent().size() == 0) {
                            $clone.prependTo($('#on-hidden-menu ul'));
                        }

                        hiddenNavBar.resize();

                    } else if (menuWidth + $('li.on-hidden:first').width() < winW) {
                        $('li.on-hidden:first').removeClass('on-hidden');
                        $('#on-hidden-menu ul li:first').remove();
                    }

                    if ($('.on-hidden').size() == 0) {
                        $('#on-hidden-menu').removeClass('open').hide();
                    }
                }, 10);
            }
        };


        $(function () {
            hiddenNavBar.init();
        })
        
        $(document).ready(function () {
    $('#myCarousel').carousel({
        interval: false
    })
    $('.fdi-Carousel .item').each(function () {
        var next = $(this).next();
        if (!next.length) {
            next = $(this).siblings(':first');
        }
        next.children(':first-child').clone().appendTo($(this));

        if (next.next().length > 0) {
            next.next().children(':first-child').clone().appendTo($(this));
        }
        else {
            $(this).siblings(':first').children(':first-child').clone().appendTo($(this));
        }
    });
});
	
		
		  jQuery(document).ready(function($) {
 
        $('#myimgcarousel').carousel({
                interval: false
        });
 
        $('#carousel-text').html($('#slide-content-0').html());
 
        //Handles the carousel thumbnails
       $('[id^=carousel-selector-]').click( function(){
            var id = this.id.substr(this.id.lastIndexOf("-") + 1);
            var id = parseInt(id);
            $('#myimgcarousel').carousel(id);
        });
 
 
        // When the carousel slides, auto update the text
        $('#myimgcarousel').on('slid.bs.carousel', function (e) {
                 var id = $('.item.active').data('slide-number');
                $('#carousel-text').html($('#slide-content-'+id).html());
        });
        
        
         var cache = {};
    $( "#doctor_name" ).autocomplete({
      minLength: 2,
      source: function( request, response ) {
        var term = request.term;
        if ( term in cache ) {
          response( cache[ term ] );
          return;
        }
		
        $.getJSON( "/wp-admin/admin-ajax.php?action=getDoctor&term="+term, request, function( data, status, xhr ) {
          cache[ term ] = data;
          response( data );
        });
      }
    });

		var location={};
		$( "#doctor_location" ).autocomplete({
      minLength: 2,
      source: function( request, response ) {
        var term = request.term;
        if ( term in location ) {
          response( location[ term ] );
          return;
        }
		
        $.getJSON( "/wp-admin/admin-ajax.php?action=getLocation&term="+term, request, function( data, status, xhr ) {
          location[ term ] = data;
          response( data );
        });
      }
    });
    
    var speciality={};
		$( "#doctor_speciality" ).autocomplete({
      minLength: 2,
      source: function( request, response ) {
        var term = request.term;
        if ( term in speciality ) {
          response( speciality[ term ] );
          return;
        }
		
        $.getJSON( "/wp-admin/admin-ajax.php?action=getSpecialist&term="+term, request, function( data, status, xhr ) {
          speciality[ term ] = data;
          response( data );
        });
      }
    });
    

  });
  
  
