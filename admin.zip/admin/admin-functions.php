<?php

/*-----------------------------------------------------------------------------------*/
/* Add default options after activation */
/*-----------------------------------------------------------------------------------*/
if (is_admin() && isset($_GET['activated'] ) && $pagenow == "themes.php?page=siteoptions" ) {
	//Call action that sets
	add_action('admin_head','tt_option_setup');
}

function tt_option_setup(){
	
	//Update EMPTY options
	$tt_array = array();
	add_option('tt_options',$tt_array);

	$template = get_option('tt_template');
	$saved_options = get_option('tt_options');
	
	foreach($template as $option) {
		if($option['type'] != 'heading'){
			$id = $option['id'];
			$std = $option['std'];
			$db_option = get_option($id);
			if(empty($db_option)){
				if(is_array($option['type'])) {
					foreach($option['type'] as $child){
						$c_id = $child['id'];
						$c_std = $child['std'];
						update_option($c_id,$c_std);
						$tt_array[$c_id] = $c_std; 
					}
				} else {
					update_option($id,$std);
					$tt_array[$id] = $std;
				}
			}
			else { //So just store the old values over again.
				$tt_array[$id] = $db_option;
			}
		}
	}
	update_option('tt_options',$tt_array);
}





/*-----------------------------------------------------------------------------------*/
/* Admin Backend */
/*-----------------------------------------------------------------------------------*/
function siteoptions_admin_head() { ?>

<script type="text/javascript">
jQuery(function(){
var message = '<p><strong>Activation Successful!</strong> This theme\'s settings are located under <a href="<?php echo admin_url('admin.php?page=siteoptions'); ?>">View Theme Options</a>.</p>';
jQuery('.themes-php #message2').html(message);
});
// tinymce.init({
   
//     menubar: "edit view",
//     theme:"modern",
//     skin:"lightgray",
//     height : "200",
//     plugins: [
// 	    'advlist autolink lists link image charmap print anchor textcolor',
// 	    'searchreplace visualblocks code',
// 	    'insertdatetime media table contextmenu paste code help'
// 	  ],
//    toolbar: 'insert | undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
// });
// tinyMCE.execCommand("mceAddEditor", false, 'verizon_order_banner');
// jQuery(".submit_themeOption").on('click',function(){
// 	tinymce.get('verizon_order_banner').save();
// });
</script>
    
    
    <?php }

add_action('admin_head', 'siteoptions_admin_head');
?>